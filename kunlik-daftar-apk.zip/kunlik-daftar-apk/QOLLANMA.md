# Kunlik Daftar — bepul APK qilish

Bu papkada mustaqil ishlaydigan ilova bor (`index.html`) — Claude artifact emas, o'zining
xotirasida (telefon brauzerida) ma'lumotni saqlaydi. Uni APK qilishning eng oson va **100% bepul**
yo'li — quyidagi 2 bosqich.

## 1-bosqich: fayllarni internetga joylash (bepul, GitHub Pages)

APK yasovchi xizmatlarga ilovangizni "internet manzili" (link) sifatida ko'rsatish kerak,
shuning uchun avval shu papkani biror joyga joylaymiz:

1. github.com'da bepul hisob oching (agar yo'q bo'lsa)
2. Yangi repository yarating, nomi masalan `kunlik-daftar`, **Public** qilib qo'ying
3. Shu papkadagi barcha fayllarni (`index.html`, `manifest.json`, `sw.js`, `icons/` papkasi)
   "Add file → Upload files" orqali yuklang
4. Repo sozlamalariga o'ting: **Settings → Pages**
5. **Source** qismida `main` branch'ni tanlang, **Save** bosing
6. Bir necha daqiqadan so'ng sizga manzil beriladi, masalan:
   `https://sizning-nomingiz.github.io/kunlik-daftar/`

Shu manzilni telefon brauzerida ochib ko'ring — ilova ishlab turgani ko'rinadi.

## 2-bosqich: APK yasash (bepul, PWABuilder)

1. Kompyuterda [pwabuilder.com](https://www.pwabuilder.com) saytiga kiring
2. Yuqoridagi GitHub Pages manzilingizni kiritib, **Start** bosing
3. Sayt ilovangizni tekshiradi (manifest, service worker allaqachon tayyor — shu papkada bor)
4. **Package for stores** yoki **Android** bo'limini tanlang
5. **Generate Package** bosing — bir necha soniyada tayyor `.apk` (yoki `.aab`) fayl yuklab olinadi

Shu — hech qanday Android Studio, hech qanday to'lov kerak emas.

## Telefonga o'rnatish

1. Yuklab olingan `.apk` faylni telefonga yuboring (Telegram, Google Drive va h.k. orqali)
2. Faylni oching, "Noma'lum manbalardan o'rnatish"ga ruxsat bering (Android so'raydi)
3. O'rnating — endi telefon ekranida oddiy ilova kabi ikonka paydo bo'ladi

## Muhim eslatma — ma'lumotlar haqida

Bu APK'dagi ma'lumotlar **telefonning o'zida** saqlanadi (brauzer xotirasi asosida), Claude
bilan hech qanday aloqasi yo'q. Ya'ni:

- ✅ Internet bo'lmasa ham ishlайveradi
- ⚠️ Ilovani o'chirib qayta o'rnatsangiz yoki telefon ma'lumotlarini tozalasangiz — yozuvlar
  ham o'chib ketadi (hech qanday bulutga zaxira yo'q)
- Xohlasangiz, keyinroq bulutga (masalan Firebase, bepul tarifi bor) zaxiralash funksiyasini
  ham qo'shib berishim mumkin — ayting

## Eng oddiy muqobil (APK'siz ham)

Agar APK bilan ovora bo'lishni istamasangiz: GitHub Pages manzilini telefon brauzerida ochib,
"Bosh ekranga qo'shish" (Add to Home Screen) tugmasini bossangiz bo'ldi — ilova xuddi APK
o'rnatilgandek ishlaydi, faqat Play Store'siz, hech qanday qo'shimcha qadamsiz.
